How high do climbers get? — Nepal Himalaya
==========================================

Open himalayas.qgz in QGIS 3.44 or newer. The data/ folder must stay next to
it (the project references it by relative path).

This is the exact project behind the live demo. To reproduce the web map:
install QGIS2WebMap by NIKA, open Web -> QGIS2WebMap -> Create web map, and
on the Map tab choose basemap Voyager and ground surface Global relief, with
the extent set to the current canvas view. Everything else is the default.

Data: The Himalayan Database (himalayandatabase.com); peak coordinates
(c) OpenStreetMap contributors, ODbL. Basemap tiles (c) CARTO,
(c) OpenStreetMap contributors.
