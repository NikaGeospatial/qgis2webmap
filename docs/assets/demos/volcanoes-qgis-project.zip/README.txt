Living next to a volcano — Indonesia
====================================

Open volcanoes.qgz in QGIS 3.44 or newer. The data/ folder must stay next to
it (the project references it by relative path).

This is the exact project behind the live demo. To reproduce the web map:
install QGIS2WebMap by NIKA, open Web -> QGIS2WebMap -> Create web map, and
on the Map tab choose basemap Dark Matter with the extent set to the current
canvas view. Everything else is the default.

Data: volcano attributes from the Smithsonian Global Volcanism Program;
hazard rings and population estimates by the NIKA team. Basemap tiles
(c) CARTO, (c) OpenStreetMap contributors.
