The MRT network — Singapore
===========================

Open singapore.qgz in QGIS 3.44 or newer. The data/ folder must stay next to
it (the project references it by relative path).

This is the exact project behind the live demo. To reproduce the web map:
install QGIS2WebMap by NIKA, open Web -> QGIS2WebMap -> Create web map, and
on the Map tab choose basemap Positron with the extent set to the current
canvas view. On the Layers tab, switch popups off for "MRT lines".
Everything else is the default.

Data: LTA DataMall + data.gov.sg (Singapore Open Data Licence v1.0); line
geometry (c) OpenStreetMap contributors, ODbL. Basemap tiles (c) CARTO,
(c) OpenStreetMap contributors.
